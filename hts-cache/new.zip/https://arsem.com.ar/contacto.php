<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Consultoría de Seguridad e Higiene y Medio Ambiente, Servicios a Consorcios, Planes de evacuacion, Seguridad en la construccion">
    <meta name="author" content="ARSEM">

    <title>ARSEM | Higiene, Seguridad &amp; Medio Ambiente</title>
    <link rel="shortcut icon" href="images/favicon.ico">

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/arsem.css" rel="stylesheet">
    
    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    
    <!-- FORM -->
    <link rel="stylesheet" href="css/animate.min.css" type="text/css">
    <link href="css/hover-min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>

<body id="inicio">

    <!-- Navigation -->
     <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="collapse navbar-collapse" style="position:a; text-align: right; width: 100%; color: white; font-size:.9em;"><i class="fa fa-envelope" style="margin-right:5px;"></i> info@arsem.com.ar&nbsp;&nbsp;&nbsp;| <i class="fa fa-phone" style="margin-right:5px; margin-left:5px;"></i> 011 5238 2578&nbsp;| <i class="fa fa-user" style="margin-right:5px; margin-left:5px;"></i><a href="http://www.arsem.com.ar/panel/login/client" target="_blank" style="color:white;"><b>ACCESO CLIENTES</b></a> | <a href="https://twitter.com/arsem_arg" target="_blank"><i class="fa fa-twitter" style="margin-right:.5em; margin-left:.5em;"></i></a><a href="https://www.facebook.com/ARSEM-1640468696203803/?fref=ts" target="_blank"><i class="fa fa-facebook" style="margin-right:.5em;"></i></a><a href="http://instagram.com/arsem_arg/" target="_blank"><i class="fa fa-instagram"></i></a></div>
            
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="index.html"><img src="images/logo-arsem.png" width="250" height="81" /></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a href="index.html#empresa2">Empresa</a>
                    </li>
                    <li class="nono">
                        <a style="padding:15px 3px 0 3px !important; font-size:0.2em;"><i class="fa fa-circle"></i></a>
                    </li>
                    <li role="presentation" class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                          Servicios <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                          <li>
                        <a href="higiene-y-seguridad.html">Higiene y Seguridad</a>
                        </li>
                        <li>
                            <a href="seguridad-en-la-construccion.html">Seguridad en la construcción</a>
                        </li>
                        <li>
                            <a href="consorcios.html">Servicios a consorcios</a>
                        </li>
                        <li>
                            <a href="planes-de-evacuacion.html">Planes de Evacuación Ley 1346 G.C.B.A.</a>
                        </li>
                        <li>
                            <a href="medio-ambiente.html">Medio Ambiente</a>
                        </li>
                        </ul>
                      </li>
                    <li class="nono">
                        <a style="padding:15px 3px 0 3px !important; font-size:0.2em;"><i class="fa fa-circle"></i></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="clientes.html">Clientes</a>
                    </li>
                    <li class="nono">
                        <a style="padding:15px 3px 0 3px !important; font-size:0.2em;"><i class="fa fa-circle"></i></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contacto.php">Contacto</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    
    <header class="contactofondo"></header>

    <!-- Page Content -->
    <div class="container">
        <!-- /.row -->

       <!-- Portfolio Section -->
        <div class="row">
            <div class="col-lg-12 page-header clientes">
                <h2 class="text-center">Contacto</h2>
            </div>
            
            <div class="col-md-12">
               
            	<div class="row">
                    <div class="col-md-6 map-responsive"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.111767256522!2d-58.461779049187356!3d-34.601335164783144!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bcca008b32472d%3A0xb28a67fb67579857!2sCucha+Cucha+2220%2C+C1416CJX+CABA!5e0!3m2!1ses-419!2sar!4v1453252050667" width="400" height="350" frameborder="0" style="border:0" allowfullscreen></iframe></div>
                    
                    <div class="col-md-4">
                        <div class="form-style" id="contact_form">
                            <div id="contact_results"></div>
                            <div id="contact_body">
                                <div class="form-group">
                                    <label>Nombre y Apellido: *</label>
                                    <input type="text" name="name" id="name" required class="input-field form-control" />
                                </div>
                                <div class="form-group">
                                    <label>E-Mail: *</label>
                                    <input type="email" name="email" required class="input-field form-control" />
                                </div>
                                <div class="form-group">
                                    <label>Teléfono:</label>
                                    <input type="email" name="phone" class="input-field form-control" />
                                </div>
                                <div class="form-group">
                                    <label>Mensaje: *</label>
                                    <textarea name="message" id="message" class="textarea-field form-control" required placeholder="Escribe aquí en qué podemos ayudarte..."></textarea>
                                </div>
                                <div class="form-group">
                                    <input type="submit" id="submit_btn" value="Enviar!" class="btn btn-primary btn-big button hvr-shrink" />
                                </div>
                                <p style="font-size:10px; color:gray;">* Campos obligatorios.</p>
                            </div>
                        </div>
                    </div>
                    

                </div>
            </div>
        
        <!-- /.row -->
        </div></div>
   
    <!-- Footer -->
        
        <footer>
            <div class="row text-center">
                <div class="col-lg-12">
                    <p class="p-footer"><i class="fa fa-envelope" style="margin-right:10px;"></i> info@arsem.com.ar <i class="fa fa-phone" style="margin-right:10px; margin-left:10px;"></i> 011 5238-2578 <i class="fa fa-map-marker" style="margin-right:10px; margin-left:10px;"></i> Cucha Cucha 2220, CABA.</p>
                    
                    <p><span style="font-size:.8em;">SEGUINOS EN</span><a href="https://twitter.com/arsem_arg" target="_blank"><i class="fa fa-twitter" style="margin-right:.5em; margin-left:.5em;"></i></a><a href="https://www.facebook.com/ARSEM-1640468696203803/?fref=ts" target="_blank"><i class="fa fa-facebook" style="margin-right:.5em;"></i></a><a href="http://instagram.com/arsem_arg/" target="_blank"><i class="fa fa-instagram"></i></a></p>
                </div>
            </div>
        </footer>
    <!-- /.container -->

   <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    
    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/jquery.fittext.js"></script>
    <script src="js/wow.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/creative.js"></script>
    
    <!-- Scrolling Nav JavaScript -->
    <script src="js/scrolling-nav.js"></script>
    
    <script src="dist/js/lightbox-plus-jquery.min.js"></script>
    
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
    
    <script type="text/javascript">
    $(document).ready(function() {
        $("#submit_btn").click(function() { 

            var proceed = true;
            //simple validation at client's end
            //loop through each field and we simply change border color to red for invalid fields		
            $("#contact_form input[required=true], #contact_form textarea[required=true]").each(function(){
                $(this).css('border-color',''); 
                if(!$.trim($(this).val())){ //if this field is empty 
                    $(this).css('border-color','red'); //change border color to red   
                    proceed = false; //set do not proceed flag
                }
                //check invalid email
                var email_reg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/; 
                if($(this).attr("type")=="email" && !email_reg.test($.trim($(this).val()))){
                    $(this).css('border-color','red'); //change border color to red   
                    proceed = false; //set do not proceed flag				
                }	
            });

            if(proceed) //everything looks good! proceed...
            {
                //get input field values data to be sent to server
                post_data = {
                    'user_name'		: $('input[name=name]').val(), 
                    'user_email'	: $('input[name=email]').val(),  
                    'user_phone'	: $('input[name=phone]').val(),  
                    'msg'			: $('textarea[name=message]').val()
                };

                //Ajax post data to server
                $.post('arsem-contact.php', post_data, function(response){  
                    if(response.type == 'error'){ //load json data from server and output message     
                        output = '<div class="error">'+response.text+'</div>';
                    }else{
                        output = '<div class="success">'+response.text+'</div>';
                        //reset values in all input fields
                        $("#contact_form  input[required=true], #contact_form textarea[required=true]").val(''); 
                        $("#contact_form #contact_body").slideUp(); //hide form after success
                    }
                    $("#contact_form #contact_results").hide().html(output).slideDown();
                }, 'json');
            }
        });

        //reset previously set border colors and hide all message on .keyup()
        $("#contact_form  input[required=true], #contact_form textarea[required=true]").keyup(function() { 
            $(this).css('border-color',''); 
            $("#result").slideUp();
        });
    });
    </script>
    
    <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

      ga('create', 'UA-78552087-1', 'auto');
      ga('send', 'pageview');

    </script>
    
    <!--Start of Zopim Live Chat Script-->
    <script type="text/javascript">
    window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
    d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
    _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
    $.src="//v2.zopim.com/?41tOTdtUsOX5godNwSZFvbLb351e609e";z.t=+new Date;$.
    type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
    </script>
    <!--End of Zopim Live Chat Script-->
</body>

</html>
